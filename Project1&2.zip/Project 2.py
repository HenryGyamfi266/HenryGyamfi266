def main():
    gotThePassword = enterThePassword()
    if gotThePassword:
        createTheStatsReport()
        
    
def enterThePassword():
    attempts = 3
    while attempts > 0:
        password = input("Enter the password: ")
        if password == "BMI2020":
            return True
        else:
            attempts -= 1
            print("You must enter the correct password. ("+str(attempts)+" attempts left)")
        
   


def createTheStatsReport():
    doIt = input(" Do you want to calculate BMI index? ")
    totalBMI = 0
    numberofBMI = 0
    a1categoryTotal = 0
    a1categoryNumber = 0
    
    a2categoryTotal = 0
    a2categoryNumber = 0

    a3categoryTotal = 0
    a3categoryNumber = 0

    a4categoryTotal = 0
    a4categoryNumber = 0
    

    
    while doIt == "yes":
            heightInfeet = int(input("Enter the height in feet: "))
            heightInInches = int(input("Enter the height in inches: "))
            weightInPounds = int(input("Enter the weight in pounds: "))
            height = (heightInfeet * 12) + heightInInches 
            BMI = (703 * weightInPounds) / (height*height)
            totalBMI += BMI
            numberofBMI += 1
            if BMI < 16.4:
                a1categoryTotal += BMI
                a1categoryNumber += 1
            elif BMI < 20.3:
                a2categoryTotal += BMI
                a2categoryNumber += 1
            elif BMI < 28.9:
                a3categoryTotal += BMI
                a3categoryNumber += 1
            else:
                a4categoryTotal += BMI
                a4categoryNumber += 1
                             
                
                
            print("Your BMI is", str(BMI))
            doIt = input(" Do you want to calculate another BMI index? ")
    outputString = "Averages of BMI categories: "
    if a1categoryNumber>0:
        outputString += "0.0-16.4: "+str(a1categoryTotal/a1categoryNumber)+", "
    if a2categoryNumber>0:
        outputString += "16.4-20.2: "+str(a2categoryTotal/a2categoryNumber)+", "
    if a3categoryNumber>0:
        outputString += "20.3-28.8: "+str(a3categoryTotal/a3categoryNumber)+", "
    if a4categoryNumber>0:
        outputString += "28.8+: "+str(a4categoryTotal/a4categoryNumber)+", "
        
    print(outputString)
    
    print("The average BMI is: ", str(totalBMI/numberofBMI))


main()
