password = input("Enter the password: ")
if password == "BMI2020":
    doIt = input(" Do you want to calculate BMI index? ")
    totalBMI = 0
    numberofBMI = 0
    while doIt == "yes":
            feet = int(input("Enter the feet: "))
            inches = int(input("Enter the inches: "))
            weight = int(input("Enter the weight: "))
            height = (feet * 12) + inches 
            BMI = (703 * weight) / (height*height)
            totalBMI += BMI
            numberofBMI += 1
            print("Your BMI is", str(BMI))
            doIt = input(" Do you want to calculate another BMI index? ")

    print("The average BMI is: ", str(totalBMI/numberofBMI))
else:
    print("You must enter the correct password")

name = Nana
for i in range(4):
    print(name)
    
