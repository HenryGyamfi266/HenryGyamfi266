from turtle import Turtle
def main():
    t1 = Turtle()

    t1.fillcolor(0,0,1)
    t1.begin_fill()
    for i in range(12):
        t1.right(30)
        t1.forward(30)
    t1.end_fill()

    
    t1.up()
    t1.left(180)
    t1.forward(25)
    t1.down()

    t1.fillcolor(1,0,0)
    t1.begin_fill()
    for i in range (12):
        t1.right(30)
        t1.forward(20)
    t1.end_fill()

    t1.up()
    t1.right(90)
    t1.forward(95)
    t1.down()

    
    t1.fillcolor(0,1,0)
    t1.begin_fill()
    for i in range(4):
        t1.right(90)
        t1.forward(20)
    t1.end_fill()

    t1.up()
    t1.right(180)
    t1.forward(20)
    t1.down()
    t1.right(90)
    t1.forward(30)
    t1.backward(80)

    t1.forward(40)
    t1.left(90)
    t1.up()
    t1.forward(30)
    t1.right(90)
    t1.forward(20)
    t1.down()
    

    t1.fillcolor(1,1,0)
    t1.begin_fill()
    for i in range(4):
        t1.right(90)
        t1.forward(6)
    t1.end_fill()

    t1.left(180)
    t1.up()
    t1.forward(40)
    t1.down()

    t1.fillcolor(1,1,0)
    t1.begin_fill()
    for i in range(4):
        t1.left(90)
        t1.forward(6)
    t1.end_fill()

    
    
        
    
    
main()
    
        
    
  










    
