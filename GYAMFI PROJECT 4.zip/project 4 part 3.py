"""
Import an image
Analyze each pixel by
changing colors
"""


import math
from images import Image

mySnowman = Image("Snowman.gif")

def main():
    invertImage(mySnowman)

def invertImage(img):
    img.draw()
    for y in range(img.getHeight()):
        print(9)
        for x in range(img.getWidth()):
            r,g,b = img.getPixel(x,y)

            img.setPixel(x,y,(r*-1+255,g*-1+255,b*-1+255))
            

                
                

    img.draw()
            

    



main()    
    
