"""
Import an image
Analyze each pixel by
changing colors
"""


import math
from images import Image
def main():
    mySnowman = Image("Snowman.gif")
    mySnowman.draw()

    for y in range(mySnowman.getHeight()):
        for x in range(mySnowman.getWidth()):
            r,g,b = mySnowman.getPixel(x,y)

            if getDistance((r,g,b),(255,0,0))<155:
                mySnowman.setPixel(x,y,(0,0,255))
            elif getDistance((r,g,b),(0,0,255))<155:
                mySnowman.setPixel(x,y,(0,255,0))
            elif getDistance((r,g,b),(0,255,0))<155:
                mySnowman.setPixel(x,y,(255,0,0))
                
                

    mySnowman.draw()
            

def getDistance(tupleA,tupleB):
    (tupleA1,tupleA2,tupleA3)=tupleA
    (tupleB1,tupleB2,tupleB3)=tupleB
    formular = math.sqrt((tupleA1-tupleB1)**2+(tupleA2-tupleB2)**2+(tupleA3-tupleB3)**2)
    #print(formular)
    return formular
    



main()    
    
